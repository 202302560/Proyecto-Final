-- ==========================================
-- 1. TABLA DE USUARIOS (Con roles)
-- ==========================================
CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    correo VARCHAR(100) UNIQUE NOT NULL,
    contrasena VARCHAR(255) NOT NULL,
    rol VARCHAR(20) DEFAULT 'empleado' CHECK (rol IN ('admin', 'empleado')),
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 2. TABLAS PRINCIPALES (Deben ir PRIMERO)
-- ==========================================
CREATE TABLE IF NOT EXISTS productos (
    id SERIAL PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    nombre VARCHAR(100) NOT NULL,
    descripcion TEXT,
    precio NUMERIC(10, 2) NOT NULL,
    stock_minimo INT DEFAULT 5,
    stock_actual INT DEFAULT 0,
    categoria VARCHAR(50),
    imagen TEXT,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS proveedores (
    id SERIAL PRIMARY KEY,
    empresa VARCHAR(100) NOT NULL,
    contacto VARCHAR(100),
    telefono VARCHAR(50),
    email VARCHAR(100),
    direccion TEXT,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 3. TABLA DE ÓRDENES DE COMPRA
-- ==========================================
CREATE TABLE IF NOT EXISTS ordenes_compra (
    id SERIAL PRIMARY KEY,
    proveedor_id INT REFERENCES proveedores(id) ON DELETE CASCADE,
    estado VARCHAR(20) DEFAULT 'pendiente', -- pendiente, completada, cancelada
    total NUMERIC(10, 2) DEFAULT 0.00,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ==========================================
-- 4. TABLA DETALLE DE ÓRDENES DE COMPRA
-- ==========================================
CREATE TABLE IF NOT EXISTS ordenes_detalle (
    id SERIAL PRIMARY KEY,
    orden_id INT REFERENCES ordenes_compra(id) ON DELETE CASCADE,
    producto_id INT REFERENCES productos(id) ON DELETE CASCADE,
    cantidad INT NOT NULL,
    precio_unitario NUMERIC(10, 2) NOT NULL
);

-- ==========================================
-- 5. FUNCIÓN Y TRIGGER PARA ACTUALIZAR STOCK
-- ==========================================
CREATE OR REPLACE FUNCTION actualizar_stock_orden()
RETURNS TRIGGER AS $$
BEGIN
  -- Verifica si la orden cambió su estado a 'completada'
  IF NEW.estado = 'completada' AND (OLD.estado IS NULL OR OLD.estado != 'completada') THEN
    
    -- Actualiza el stock sumando la cantidad del detalle correspondiente
    UPDATE productos p
    SET stock_actual = p.stock_actual + d.cantidad
    FROM ordenes_detalle d
    WHERE d.orden_id = NEW.id 
      AND p.id = d.producto_id;

  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Limpieza y creación del trigger
DROP TRIGGER IF EXISTS trg_actualizar_stock ON ordenes_compra;

CREATE TRIGGER trg_actualizar_stock
AFTER UPDATE ON ordenes_compra
FOR EACH ROW
EXECUTE FUNCTION actualizar_stock_orden();

-- ==========================================
-- 6. DATOS INICIALES
-- ==========================================
INSERT INTO usuarios (nombre, correo, contrasena, rol) 
VALUES ('Empleado', 'empleado@supermercado.com', 'Empleado123', 'empleado')
ON CONFLICT (correo) DO NOTHING;

-- 1. Crear la tabla de órdenes de compra
CREATE TABLE IF NOT EXISTS ordenes_compra (
    id SERIAL PRIMARY KEY,
    proveedor_id INT REFERENCES proveedores(id) ON DELETE CASCADE,
    estado VARCHAR(20) DEFAULT 'pendiente', -- pendiente, completada, cancelada
    total NUMERIC(10, 2) DEFAULT 0.00,
    creado_en TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Crear la tabla de detalle de órdenes
CREATE TABLE IF NOT EXISTS ordenes_detalle (
    id SERIAL PRIMARY KEY,
    orden_id INT REFERENCES ordenes_compra(id) ON DELETE CASCADE,
    producto_id INT REFERENCES productos(id) ON DELETE CASCADE,
    cantidad INT NOT NULL,
    precio_unitario NUMERIC(10, 2) NOT NULL
);