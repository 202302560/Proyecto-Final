import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-proveedores',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './proveedores.component.html'
})
export class ProveedoresComponent implements OnInit {
  proveedores: any[] = [];
  
  // Objeto con la propiedad de 'direccion' integrada
  nuevo: any = { 
    empresa: '', 
    contacto: '', 
    telefono: '', 
    email: '',
    direccion: '' 
  };

  editando: boolean = false;
  idProveedorEditando: number | null = null;
  esAdmin: boolean = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.esAdmin = localStorage.getItem('rol') === 'admin';
    }
    this.cargar();
  }

  cargar(): void {
    this.apiService.getProveedores().subscribe({
      next: (res: any) => {
        this.proveedores = res;
      },
      error: (err) => {
        console.error('Error al cargar proveedores:', err);
      }
    });
  }

  guardar(): void {
    if (!this.nuevo.empresa) {
      alert('Por favor completa al menos el nombre de la empresa.');
      return;
    }

    if (this.editando && this.idProveedorEditando !== null) {
      // MODO ACTUALIZAR
      this.apiService.actualizarProveedor(this.idProveedorEditando, this.nuevo).subscribe({
        next: () => {
          alert('¡Proveedor actualizado exitosamente!');
          this.resetFormulario();
          this.cargar();
        },
        error: (err) => {
          console.error('Error al actualizar proveedor:', err);
          alert('No se pudo actualizar el proveedor.');
        }
      });
    } else {
      // MODO CREAR
      this.apiService.crearProveedor(this.nuevo).subscribe({
        next: () => {
          alert('¡Proveedor guardado exitosamente!');
          this.resetFormulario();
          this.cargar();
        },
        error: (err) => {
          console.error('Error al guardar proveedor:', err);
          alert('No se pudo registrar el proveedor.');
        }
      });
    }
  }

  prepararEdicion(pr: any): void {
    this.editando = true;
    this.idProveedorEditando = pr.id;
    this.nuevo = {
      empresa: pr.empresa,
      contacto: pr.contacto || '',
      telefono: pr.telefono || '',
      email: pr.email || '',
      direccion: pr.direccion || ''
    };
  }

  cancelarEdicion(): void {
    this.resetFormulario();
  }

  resetFormulario(): void {
    this.editando = false;
    this.idProveedorEditando = null;
    this.nuevo = { 
      empresa: '', 
      contacto: '', 
      telefono: '', 
      email: '',
      direccion: '' 
    };
  }

  eliminar(id: number): void {
    if (confirm('¿Desea eliminar este proveedor?')) {
      this.apiService.eliminarProveedor(id).subscribe({
        next: () => {
          this.cargar();
        },
        error: (err) => {
          console.error('Error al eliminar proveedor:', err);
          alert('No tienes permisos para realizar esta acción o el proveedor está asociado a órdenes.');
        }
      });
    }
  }
}