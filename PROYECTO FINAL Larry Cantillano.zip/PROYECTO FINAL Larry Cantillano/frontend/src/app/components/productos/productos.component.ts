import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-productos',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './productos.component.html'
})
export class ProductosComponent implements OnInit {
  productos: any[] = [];
  
  nuevo: any = { 
    codigo: '', 
    nombre: '', 
    descripcion: '', 
    precio: null, 
    stock_minimo: 5, 
    stock_actual: 0, 
    categoria: '',
    imagen: ''
  };

  editando: boolean = false;
  idProductoEditando: number | null = null;
  esAdmin: boolean = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void { 
    if (typeof window !== 'undefined') {
      this.esAdmin = localStorage.getItem('rol') === 'admin';
    }
    this.cargar(); 
  }

  cargar(): void { 
    this.apiService.getProductos().subscribe({
      next: (res: any) => {
        this.productos = res;
      },
      error: (err) => {
        console.error('Error al cargar productos:', err);
      }
    }); 
  }
  
  guardar(): void {
    if (!this.nuevo.codigo || !this.nuevo.nombre || this.nuevo.precio === null || this.nuevo.precio === undefined) {
      alert('Por favor completa los campos obligatorios (Código, Nombre y Precio).');
      return;
    }

    if (this.editando && this.idProductoEditando !== null) {
      // MODO ACTUALIZAR
      this.apiService.actualizarProducto(this.idProductoEditando, this.nuevo).subscribe({
        next: () => {
          alert('¡Producto actualizado exitosamente!');
          this.resetFormulario();
          this.cargar();
        },
        error: (err) => {
          console.error('Error al actualizar:', err);
          alert('No se pudo actualizar el producto.');
        }
      });
    } else {
      // MODO CREAR
      this.apiService.crearProducto(this.nuevo).subscribe({
        next: () => {
          alert('¡Producto guardado exitosamente!');
          this.resetFormulario();
          this.cargar(); 
        },
        error: (err) => {
          console.error('Error al guardar producto:', err);
          const mensajeError = err.error?.mensaje || 'Error al conectar con el servidor.';
          alert(`No se pudo guardar: ${mensajeError}`);
        }
      });
    }
  }

  // Cargar datos en el formulario para editar
  prepararEdicion(p: any): void {
    this.editando = true;
    this.idProductoEditando = p.id;
    this.nuevo = { 
      codigo: p.codigo, 
      nombre: p.nombre, 
      descripcion: p.descripcion || '', 
      precio: p.precio, 
      stock_minimo: p.stock_minimo, 
      stock_actual: p.stock_actual, 
      categoria: p.categoria || '',
      imagen: p.imagen || ''
    };
  }

  // Cancelar la edicion y limpiar
  cancelarEdicion(): void {
    this.resetFormulario();
  }

  resetFormulario(): void {
    this.editando = false;
    this.idProductoEditando = null;
    this.nuevo = { 
      codigo: '', 
      nombre: '', 
      descripcion: '', 
      precio: null, 
      stock_minimo: 5, 
      stock_actual: 0, 
      categoria: '',
      imagen: ''
    };
  }

  eliminar(id: number): void {
    if (confirm('¿Desea eliminar este producto?')) {
      this.apiService.eliminarProducto(id).subscribe({
        next: () => {
          this.cargar();
        },
        error: (err) => {
          console.error('Error al eliminar producto:', err);
          alert('No tienes permisos para realizar esta acción.');
        }
      });
    }
  }
}