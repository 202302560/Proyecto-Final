import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './login.component.html',
  styles: [`
    :host {
      display: block;
      height: 100vh;
    }
  `]
})
export class LoginComponent {
  correo = '';
  contrasena = '';
  errorMensaje = '';

  constructor(private apiService: ApiService, private router: Router) {}

  onLogin() {
    this.errorMensaje = ''; // Limpiar errores previos

    this.apiService.login({ correo: this.correo, contrasena: this.contrasena }).subscribe({
      next: (res: any) => {
        // Guardar los datos clave en el almacenamiento local del navegador
        localStorage.setItem('token', res.token);
        localStorage.setItem('rol', res.rol);         // Guarda 'admin' o 'empleado'
        localStorage.setItem('nombre', res.nombre);

        // Mensaje de bienvenida para cada rol
        const rolTexto = res.rol === 'admin' ? 'Administrador' : 'Empleado';
        alert(`¡Bienvenido, ${res.nombre} (${rolTexto})!`);

        // Redireccion al Dashboard
        this.router.navigate(['/dashboard']);
      },
      error: (err) => {
        // Capturar de forma segura el mensaje de error del backend
        this.errorMensaje = err.error?.mensaje || 'Error al conectar con el servidor';
      }
    });
  }
}