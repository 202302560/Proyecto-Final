import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../services/api.service';

@Component({
  selector: 'app-ordenes',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './ordenes.component.html'
})
export class OrdenesComponent implements OnInit {
  ordenes: any[] = [];
  proveedores: any[] = [];
  productosDisponibles: any[] = [];

  // Objeto para la nueva orden
  nuevaOrden: any = {
    proveedor_id: null,
    productos: []
  };

  // Item temporal para añadir al detalle de la orden
  itemTemporal: any = {
    producto_id: null,
    cantidad: 1,
    precio_unitario: 0
  };

  esAdmin: boolean = false;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    if (typeof window !== 'undefined') {
      this.esAdmin = localStorage.getItem('rol') === 'admin';
    }
    this.cargarDatos();
  }

  cargarDatos(): void {
    // Cargar ordenes
    this.apiService.getOrdenes().subscribe({
      next: (res: any) => this.ordenes = res,
      error: (err) => console.error('Error al cargar órdenes:', err)
    });

    // Cargar proveedores para el select
    this.apiService.getProveedores().subscribe({
      next: (res: any) => this.proveedores = res,
      error: (err) => console.error('Error al cargar proveedores:', err)
    });

    // Cargar productos para el select del detalle
    this.apiService.getProductos().subscribe({
      next: (res: any) => this.productosDisponibles = res,
      error: (err) => console.error('Error al cargar productos:', err)
    });
  }

  agregarProductoAlDetalle(): void {
    if (!this.itemTemporal.producto_id || this.itemTemporal.cantidad <= 0) {
      alert('Selecciona un producto y una cantidad válida.');
      return;
    }

    const productoSeleccionado = this.productosDisponibles.find(p => p.id == this.itemTemporal.producto_id);
    if (!productoSeleccionado) return;

    this.nuevaOrden.productos.push({
      producto_id: productoSeleccionado.id,
      nombre: productoSeleccionado.nombre,
      cantidad: Number(this.itemTemporal.cantidad),
      precio_unitario: Number(productoSeleccionado.precio)
    });

    // Limpiar item temporal
    this.itemTemporal = { producto_id: null, cantidad: 1, precio_unitario: 0 };
  }

  removerItem(index: number): void {
    this.nuevaOrden.productos.splice(index, 1);
  }

  calcularTotalTemporal(): number {
    return this.nuevaOrden.productos.reduce(
      (acc: number, item: any) => acc + (item.cantidad * item.precio_unitario),
      0
    );
  }

  guardarOrden(): void {
    if (!this.nuevaOrden.proveedor_id || this.nuevaOrden.productos.length === 0) {
      alert('Selecciona un proveedor y al menos un producto.');
      return;
    }

    this.apiService.crearOrden(this.nuevaOrden).subscribe({
      next: () => {
        alert('¡Orden de compra creada exitosamente!');
        this.nuevaOrden = { proveedor_id: null, productos: [] };
        this.cargarDatos();
      },
      error: (err: any) => {
        console.error('Error al crear orden:', err);
        alert('No se pudo registrar la orden de compra.');
      }
    });
  }

  cambiarEstado(id: number, estado: string): void {
    if (confirm(`¿Deseas marcar esta orden como '${estado}'?`)) {
      this.apiService.actualizarEstadoOrden(id, estado).subscribe({
        next: () => {
          alert(`Orden actualizada a '${estado}'. ¡Stock actualizado si fue completada!`);
          this.cargarDatos();
        },
        error: (err) => {
          console.error('Error al actualizar estado:', err);
          alert('No se pudo cambiar el estado de la orden.');
        }
      });
    }
  }
}