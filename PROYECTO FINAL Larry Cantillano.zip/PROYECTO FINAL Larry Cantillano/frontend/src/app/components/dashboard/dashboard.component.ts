import { Component, OnInit, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ApiService } from '../../services/api.service';
import { Chart, registerables } from 'chart.js';

Chart.register(...registerables);

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule],
  template: `
    <div class="container mt-4 mb-5">
      <h2 class="mb-4 text-danger fw-bold">Dashboard de Inventario</h2>
      
      <div class="row">
        <div class="col-lg-8 mb-4">
          <div class="card shadow-sm h-100">
            <div class="card-header bg-danger text-white fw-bold">Alertas de Stock Bajo</div>
            <div class="card-body p-0">
              <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                  <thead>
                    <tr>
                      <th class="ps-3">Código</th>
                      <th>Producto</th>
                      <th>Categoría</th>
                      <th>Stock Actual</th>
                      <th class="pe-3">Stock Mínimo</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr *ngFor="let p of resumen.productos_stock_bajo">
                      <td class="ps-3 fw-bold">{{ p.codigo }}</td>
                      <td>{{ p.nombre }}</td>
                      <td>{{ p.categoria }}</td>
                      <td class="text-danger fw-bold">
                        <span class="badge bg-danger">{{ p.stock_actual }}</span>
                      </td>
                      <td class="pe-3">{{ p.stock_minimo }}</td>
                    </tr>
                    <tr *ngIf="resumen.productos_stock_bajo.length === 0">
                      <td colspan="5" class="text-center text-muted py-4">
                        No hay productos con stock bajo en este momento.
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>

        <div class="col-lg-4">
          <div class="d-flex flex-column gap-3 mb-4">
            <div class="card p-3 shadow-sm border">
              <div class="text-muted small">Total Productos</div>
              <h3 class="text-danger fw-bold mb-0 mt-1">{{ resumen.totales.productos }}</h3>
            </div>
            
            <div class="card p-3 shadow-sm border">
              <div class="text-muted small">Total Proveedores</div>
              <h3 class="text-danger fw-bold mb-0 mt-1">{{ resumen.totales.proveedores }}</h3>
            </div>
            
            <div class="card p-3 shadow-sm border">
              <div class="text-muted small">Órdenes de Compra</div>
              <h3 class="text-danger fw-bold mb-0 mt-1">{{ resumen.totales.ordenes }}</h3>
            </div>
          </div>

          <!-- Grafico para resumen del dashboard -->
          <div class="card p-3 shadow-sm border">
            <h6 class="fw-bold text-secondary mb-2">Distribución General</h6>
            <div style="position: relative; height: 180px; width: 100%;">
              <canvas id="ordenesChart"></canvas>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
})
export class DashboardComponent implements OnInit, AfterViewInit {
  resumen: any = {
    totales: {
      productos: 0,
      proveedores: 0,
      ordenes: 0
    },
    productos_stock_bajo: []
  };

  private chart: any;

  constructor(private apiService: ApiService, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    this.cargarResumen();
  }

  ngAfterViewInit(): void {}

  cargarResumen(): void {
    this.apiService.getResumenDashboard().subscribe({
      next: (res: any) => {
        console.log('DATOS RECIBIDOS DEL DASHBOARD:', res);
        if (res) {
          this.resumen = res;
          this.cdr.detectChanges();
          setTimeout(() => this.renderizarGrafico(), 100);
        }
      },
      error: (err) => {
        console.error('Error al cargar datos del dashboard:', err);
      }
    });
  }

  renderizarGrafico(): void {
    const canvas = document.getElementById('ordenesChart') as HTMLCanvasElement;
    if (!canvas) return;

    if (this.chart) {
      this.chart.destroy();
    }

    this.chart = new Chart(canvas, {
      type: 'bar',
      data: {
        labels: ['Productos', 'Proveedores', 'Órdenes'],
        datasets: [{
          data: [
            this.resumen.totales.productos, 
            this.resumen.totales.proveedores, 
            this.resumen.totales.ordenes
          ],
          backgroundColor: ['#dc3545', '#ffc107', '#198754'],
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          y: { beginAtZero: true }
        }
      }
    });
  }
}