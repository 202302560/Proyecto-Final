import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private apiUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) {}

  private getHeaders() {
    // Verificar que estemos en el navegador antes de buscar el token
    let token = null;
    if (typeof window !== 'undefined' && localStorage) {
      token = localStorage.getItem('token');
    }

    return {
      headers: new HttpHeaders({
        'Authorization': `Bearer ${token}`
      })
    };
  }

  // Login
  login(credentials: any): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, credentials);
  }

  // Productos
  getProductos(): Observable<any> { return this.http.get(`${this.apiUrl}/productos`, this.getHeaders()); }
  crearProducto(p: any): Observable<any> { return this.http.post(`${this.apiUrl}/productos`, p, this.getHeaders()); }
  actualizarProducto(id: number, p: any): Observable<any> { 
    return this.http.put(`${this.apiUrl}/productos/${id}`, p, this.getHeaders()); 
  }
  eliminarProducto(id: number): Observable<any> { return this.http.delete(`${this.apiUrl}/productos/${id}`, this.getHeaders()); }

  // Proveedores
  getProveedores(): Observable<any> { return this.http.get(`${this.apiUrl}/proveedores`, this.getHeaders()); }
  crearProveedor(pr: any): Observable<any> { return this.http.post(`${this.apiUrl}/proveedores`, pr, this.getHeaders()); }
  actualizarProveedor(id: number, pr: any): Observable<any> { 
    return this.http.put(`${this.apiUrl}/proveedores/${id}`, pr, this.getHeaders()); 
  }
  eliminarProveedor(id: number): Observable<any> { 
    return this.http.delete(`${this.apiUrl}/proveedores/${id}`, this.getHeaders()); 
  }

  // Ordenes de Compra
  getOrdenes(): Observable<any> { return this.http.get(`${this.apiUrl}/ordenes`, this.getHeaders()); }
  
  // Metodo correcto para crear la orden de compra
  crearOrden(orden: any): Observable<any> { 
    return this.http.post(`${this.apiUrl}/ordenes`, orden, this.getHeaders()); 
  }

  actualizarEstadoOrden(id: number, estado: string): Observable<any> { 
    return this.http.put(`${this.apiUrl}/ordenes/${id}/estado`, { estado }, this.getHeaders()); 
  }

  // Dashboard
  getResumenDashboard(): Observable<any> { return this.http.get(`${this.apiUrl}/dashboard/resumen`, this.getHeaders()); }
}