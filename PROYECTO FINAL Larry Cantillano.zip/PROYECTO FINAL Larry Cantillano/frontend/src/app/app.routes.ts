import { inject } from '@angular/core';
import { CanActivateFn, Router, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { ProductosComponent } from './components/productos/productos.component';
import { ProveedoresComponent } from './components/proveedores/proveedores.component';
import { OrdenesComponent } from './components/ordenes/ordenes.component';

const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('token');

  if (!token) {
    return router.createUrlTree(['/login'], {
      queryParams: { returnUrl: state.url }
    });
  }

  const requiredRole = route.data?.['rol'];
  const userRole = localStorage.getItem('rol');

  return !requiredRole || userRole === requiredRole;
};

export const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: 'login', component: LoginComponent },
  
  // Rutas protegidas para cualquier usuario autenticado (admin o empleado)
  { path: 'dashboard', component: DashboardComponent, canActivate: [authGuard] },
  { path: 'productos', component: ProductosComponent, canActivate: [authGuard] },
  { path: 'ordenes', component: OrdenesComponent, canActivate: [authGuard] },

  // Ruta EXCLUSIVA para el Administrador
  { 
    path: 'proveedores', 
    component: ProveedoresComponent, 
    canActivate: [authGuard], 
    data: { rol: 'admin' } 
  },

  { path: '**', redirectTo: 'login' }
];