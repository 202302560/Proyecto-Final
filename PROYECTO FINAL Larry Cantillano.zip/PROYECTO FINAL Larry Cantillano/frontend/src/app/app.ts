import { Component } from '@angular/core';
import { Router, RouterOutlet, RouterLink, RouterLinkActive } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, RouterLinkActive],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class AppComponent {
  constructor(public router: Router) {}

  mostrarNavbar(): boolean {
    // Validamos que estemos en el navegador antes de usar localStorage
    if (typeof window === 'undefined' || !localStorage) {
      return false;
    }

    const tieneToken = !!localStorage.getItem('token');
    const noEsLogin = this.router.url !== '/login' && this.router.url !== '/';
    return tieneToken && noEsLogin;
  }

  logout(): void {
    if (typeof window !== 'undefined' && localStorage) {
      localStorage.clear();
    }
    this.router.navigate(['/login']);
  }
}