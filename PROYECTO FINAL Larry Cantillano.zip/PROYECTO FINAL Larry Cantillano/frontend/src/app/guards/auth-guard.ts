import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { PLATFORM_ID } from '@angular/core';
import { isPlatformBrowser } from '@angular/common';

export const authGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const platformId = inject(PLATFORM_ID);

  // Si no estamos en el navegador, denegamos el acceso al servidor de inmediato
  if (!isPlatformBrowser(platformId)) {
    return router.createUrlTree(['/login']);
  }

  // 2. Lectura segura utilizando window.localStorage explicitamente
  const token = window.localStorage.getItem('token');

  if (!token) {
    return router.createUrlTree(['/login'], {
      queryParams: { returnUrl: state.url }
    });
  }

  const requiredRole = route.data?.['rol'] as string | undefined;
  if (requiredRole) {
    const userRole = window.localStorage.getItem('rol');
    if (userRole !== requiredRole) {
      return router.createUrlTree(['/dashboard']);
    }
  }

  return true;
};