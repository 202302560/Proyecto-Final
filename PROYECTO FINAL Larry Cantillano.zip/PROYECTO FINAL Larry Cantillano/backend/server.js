const express = require('express');
const cors = require('cors');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');

const app = express();
app.use(cors());
app.use(express.json());

const pool = new Pool({
  user: 'postgres',
  host: 'localhost',
  database: 'supermercado_db',
  password: 'baleada26',
  port: 5432,
});

// Middleware JWT para autenticar usuarios
const verificarToken = (req, res, next) => {
  const token = req.headers['authorization'];
  if (!token) return res.status(403).json({ mensaje: 'Token requerido' });

  try {
    const bearer = token.split(' ')[1] || token;
    const decoded = jwt.verify(bearer, 'SECRET_KEY_SUPERMERCADO');
    req.usuario = decoded; // Contiene { id, rol }
    next();
  } catch (err) {
    return res.status(401).json({ mensaje: 'Token inválido o expirado' });
  }
};

// Middleware para verificar si es Admin
const verificarAdmin = (req, res, next) => {
  if (req.usuario && req.usuario.rol === 'admin') {
    next();
  } else {
    return res.status(403).json({ mensaje: 'Acceso denegado: Se requiere rol de Administrador' });
  }
};

// MÓDULO 1: AUTENTICACION
app.post('/api/login', async (req, res) => {
  const { correo, contrasena } = req.body;

  try {
    const result = await pool.query('SELECT * FROM usuarios WHERE correo = $1', [correo]);
    if (result.rows.length === 0) {
      return res.status(401).json({ mensaje: 'Usuario no encontrado' });
    }

    const usuario = result.rows[0];
    const hashGuardado = usuario.contrasena || usuario.password;

    let passwordMatch = false;
    if (hashGuardado.startsWith('$2b$') || hashGuardado.startsWith('$2a$')) {
      passwordMatch = await bcrypt.compare(contrasena, hashGuardado);
    } else {
      passwordMatch = (contrasena === hashGuardado);
    }

    if (!passwordMatch) {
      return res.status(401).json({ mensaje: 'Contraseña incorrecta' });
    }

    const token = jwt.sign(
      { id: usuario.id, rol: usuario.rol },
      'SECRET_KEY_SUPERMERCADO',
      { expiresIn: '8h' }
    );

    console.log(`[LOGIN EXITOSO] Usuario: ${usuario.correo} | Rol: ${usuario.rol}`);
    res.json({ token, nombre: usuario.nombre, rol: usuario.rol });

  } catch (error) {
    console.error('--- ERROR EN LOGIN ---', error);
    res.status(500).json({ mensaje: 'Error interno del servidor', detalle: error.message });
  }
});

// MODULO 2: GESTION DE PRODUCTOS
app.get('/api/productos', verificarToken, async (req, res) => {
  try {
    const query = `
      SELECT *, 
        CASE WHEN stock_actual < stock_minimo THEN true ELSE false END AS alerta_stock 
      FROM productos ORDER BY id DESC;
    `;
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (error) {
    console.error('--- ERROR EN GET /api/productos ---', error);
    res.status(500).json({ mensaje: 'Error al obtener productos', detalle: error.message });
  }
});

app.post('/api/productos', verificarToken, async (req, res) => {
  const { codigo, nombre, descripcion, precio, stock_minimo, stock_actual, categoria, imagen } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO productos (codigo, nombre, descripcion, precio, stock_minimo, stock_actual, categoria, imagen)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING *`,
      [codigo, nombre, descripcion, precio, stock_minimo || 5, stock_actual || 0, categoria, imagen]
    );
    res.status(201).json({ mensaje: 'Producto creado', producto: result.rows[0] });
  } catch (error) {
    console.error('--- ERROR EN POST /api/productos ---', error);
    res.status(500).json({ mensaje: 'Error al crear producto', detalle: error.message });
  }
});

app.put('/api/productos/:id', verificarToken, async (req, res) => {
  const { id } = req.params;
  const { codigo, nombre, descripcion, precio, stock_minimo, stock_actual, categoria, imagen } = req.body;
  try {
    const result = await pool.query(
      `UPDATE productos 
       SET codigo=$1, nombre=$2, descripcion=$3, precio=$4, stock_minimo=$5, stock_actual=$6, categoria=$7, imagen=$8
       WHERE id=$9 RETURNING *`,
      [codigo, nombre, descripcion, precio, stock_minimo, stock_actual, categoria, imagen, id]
    );
    res.json({ mensaje: 'Producto actualizado', producto: result.rows[0] });
  } catch (error) {
    console.error('--- ERROR EN PUT /api/productos ---', error);
    res.status(500).json({ mensaje: 'Error al actualizar producto', detalle: error.message });
  }
});

// Solo administradores pueden eliminar productos
app.delete('/api/productos/:id', [verificarToken, verificarAdmin], async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM productos WHERE id = $1', [id]);
    res.json({ mensaje: 'Producto eliminado' });
  } catch (error) {
    console.error('--- ERROR EN DELETE /api/productos ---', error);
    res.status(500).json({ mensaje: 'Error al eliminar producto', detalle: error.message });
  }
});

// MODULO 3: GESTION DE PROVEEDORES
app.get('/api/proveedores', verificarToken, async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM proveedores ORDER BY id DESC');
    res.json(result.rows);
  } catch (error) {
    console.error('--- ERROR EN GET /api/proveedores ---', error);
    res.status(500).json({ mensaje: 'Error al obtener proveedores', detalle: error.message });
  }
});

app.post('/api/proveedores', verificarToken, async (req, res) => {
  const { empresa, contacto, telefono, email, direccion } = req.body;
  try {
    const result = await pool.query(
      `INSERT INTO proveedores (empresa, contacto, telefono, email, direccion)
       VALUES ($1, $2, $3, $4, $5) RETURNING *`,
      [empresa, contacto, telefono, email, direccion || null]
    );
    res.status(201).json({ mensaje: 'Proveedor registrado', proveedor: result.rows[0] });
  } catch (error) {
    console.error('--- ERROR EN POST /api/proveedores ---', error);
    res.status(500).json({ mensaje: 'Error al registrar proveedor', detalle: error.message });
  }
});

app.put('/api/proveedores/:id', verificarToken, async (req, res) => {
  const { id } = req.params;
  const { empresa, contacto, telefono, email, direccion } = req.body;
  try {
    const result = await pool.query(
      `UPDATE proveedores 
       SET empresa=$1, contacto=$2, telefono=$3, email=$4, direccion=$5 
       WHERE id=$6 RETURNING *`,
      [empresa, contacto, telefono, email, direccion || null, id]
    );
    res.json({ mensaje: 'Proveedor actualizado', proveedor: result.rows[0] });
  } catch (error) {
    console.error('--- ERROR EN PUT /api/proveedores ---', error);
    res.status(500).json({ mensaje: 'Error al actualizar proveedor', detalle: error.message });
  }
});

// Solo administradores pueden eliminar proveedores
app.delete('/api/proveedores/:id', [verificarToken, verificarAdmin], async (req, res) => {
  const { id } = req.params;
  try {
    await pool.query('DELETE FROM proveedores WHERE id = $1', [id]);
    res.json({ mensaje: 'Proveedor eliminado' });
  } catch (error) {
    console.error('--- ERROR EN DELETE /api/proveedores ---', error);
    res.status(500).json({ mensaje: 'Error al eliminar proveedor', detalle: error.message });
  }
});

// MODULO 4: ORDENES DE COMPRA
app.get('/api/ordenes', verificarToken, async (req, res) => {
  try {
    const query = `
      SELECT o.id, o.estado, o.total, o.creado_en, p.empresa AS proveedor
      FROM ordenes_compra o
      JOIN proveedores p ON o.proveedor_id = p.id
      ORDER BY o.id DESC;
    `;
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (error) {
    console.error('--- ERROR EN GET /api/ordenes ---', error);
    res.status(500).json({ mensaje: 'Error al obtener órdenes', detalle: error.message });
  }
});

app.post('/api/ordenes', verificarToken, async (req, res) => {
  const { proveedor_id, productos } = req.body; 
  const client = await pool.connect();

  try {
    await client.query('BEGIN');

    let total = 0;
    productos.forEach(p => {
      total += Number(p.cantidad) * Number(p.precio_unitario);
    });

    const ordenRes = await client.query(
      `INSERT INTO ordenes_compra (proveedor_id, total, estado) VALUES ($1, $2, 'pendiente') RETURNING id`,
      [Number(proveedor_id), total]
    );
    const ordenId = ordenRes.rows[0].id;

    for (const prod of productos) {
      await client.query(
        `INSERT INTO ordenes_detalle (orden_id, producto_id, cantidad, precio_unitario) VALUES ($1, $2, $3, $4)`,
        [ordenId, Number(prod.producto_id), Number(prod.cantidad), Number(prod.precio_unitario)]
      );
    }

    await client.query('COMMIT');
    res.status(201).json({ mensaje: 'Orden de compra creada', orden_id: ordenId });
  } catch (error) {
    await client.query('ROLLBACK');
    console.error('--- ERROR DETALLADO AL CREAR ORDEN ---', error);
    res.status(500).json({ mensaje: 'Error al crear la orden', detalle: error.message });
  } finally {
    client.release();
  }
});

app.put('/api/ordenes/:id/estado', verificarToken, async (req, res) => {
  const { id } = req.params;
  const { estado } = req.body; // 'completada' o 'cancelada'

  try {
    const result = await pool.query(
      `UPDATE ordenes_compra SET estado = $1 WHERE id = $2 RETURNING *`,
      [estado, id]
    );
    res.json({ mensaje: `Estado de la orden actualizado a ${estado}`, orden: result.rows[0] });
  } catch (error) {
    console.error('--- ERROR EN PUT /api/ordenes/estado ---', error);
    res.status(500).json({ mensaje: 'Error al actualizar el estado de la orden', detalle: error.message });
  }
});

// ==========================================
// MODULO 5: DASHBOARD / REPORTES
// ==========================================
app.get('/api/dashboard/resumen', verificarToken, async (req, res) => {
  try {
    const totalProductos = await pool.query('SELECT COUNT(*) FROM productos');
    const totalProveedores = await pool.query('SELECT COUNT(*) FROM proveedores');
    const totalOrdenes = await pool.query('SELECT COUNT(*) FROM ordenes_compra');
    const stockBajo = await pool.query('SELECT * FROM productos WHERE stock_actual < stock_minimo');

    res.json({
      totales: {
        productos: parseInt(totalProductos.rows[0].count),
        proveedores: parseInt(totalProveedores.rows[0].count),
        ordenes: parseInt(totalOrdenes.rows[0].count)
      },
      productos_stock_bajo: stockBajo.rows
    });
  } catch (error) {
    console.error('--- ERROR EN DASHBOARD ---', error);
    res.status(500).json({ mensaje: 'Error al cargar datos del dashboard', detalle: error.message });
  }
});

const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Servidor del Supermercado corriendo en el puerto ${PORT}`);
});